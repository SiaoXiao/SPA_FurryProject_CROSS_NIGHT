<script setup>
import { onMounted, onUnmounted, reactive, ref } from "vue";
import Layout from '@/components/Layout/index.vue'
// 滾輪按鈕開關
const isActive = ref(false);

// 顯示滾輪按鈕
const handleScroll = () => {
  if (window.scrollY >= 100) {
    isActive.value = true;
  } else {
    isActive.value = false;
  }
};

// 回到最上層
const handleScrollTop = () => {
  window.scroll({
    top: 0,
    behavior: "smooth",
  });
};

// App.vue init
const init = onMounted(async () => {
  // 新增滾輪監聽事件
  window.addEventListener("scroll", handleScroll);
  document.oncontextmenu = function () {
    return false;
  };
});

// 移除滾輪監聽事件
onUnmounted(() => {
  window.removeEventListener("scroll", handleScroll);
});


</script>

<template>
  <Layout />
  <div v-show="isActive" class="scrollBtn" @click.passive="handleScrollTop">
    Top
  </div>
</template>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: Noto Sans TC, 'sans-serif';
}

body {
  position: relative;
  width: 100%;
  max-width: 1920px;
  min-height: 100vh;
  margin: 0 auto;
}
.scrollBtn {
  position: fixed;
  width: 50px;
  height: 50px;
  background: #000;
  color: #fff;
  bottom: 5%;
  right: 5%;
  border-radius: 5px;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  z-index: 10;
}
</style>