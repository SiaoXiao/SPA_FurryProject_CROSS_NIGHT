<template>
  <div
    class="max-w-screen-xl h-full w-full flex justify-center items-center flex-col-reverse sm:flex-row mb-10"
  >
    <div class="flex justify-center items-center flex-col gap-2 w-full">
      <h2 class="text-2xl text-gray-900 tracking-wider">關於團隊</h2>
      <span class="text-sm text-gray-500 tracking-wider"> ABOUT ME </span>
      <div>
        <p class="text-base text-gray-900 tracking-wider">
          我們是
          <a
            href="https://www.facebook.com/CrossNightFurry?eid=ARDh4oTXrE9Pv0iRaq80TfipPk9TRL8x7g2x7qgWspo490kcZfShZePbdnEV3RDWC1JRfnbYPbD0VaVz&hc_ref=ARQTMSQ2wbRd0lOaps2HfOGnd3Ug2yZ9wVrycKRYGhpZAglHXRa7H_9imyzVjPQR624&fref=nf&__xts__[0]=68.ARBWnzU_pDlo5UXzSMNMMDhWBAq024FIZ-Otq6yfg3hpHskmexVa7w3HF9PtxdLjEL41nRqWitejUgtflJ_WNpvw9pjKJVvH2EqQw3ZC0rPcCiGrkyF_4TfOHFs0rx3HObzFmtEmhWb763aYvX23ipC87cmHvosLOL-v1h24hi1Um9JASHWcUxbr2Mm_bHXjvROE1kTKVrbmR4I5xPOJL_wq7xACV9nKRnnrgiCFRdx3bpxBkgPL7KaV3BkMyNzUKbx9_l0wm_dZaY8KxlTuqkLXYI7GWp1OvfqRLy2poTFt6T6HC3lNcQPk70-xScVL1r4"
            target="_blank"
            class="font-bold text-fuchsia-400 tracking-wider text-lg"
            >Cross Night Furry</a
          >
          -
          是以台灣中部Furry活動的小組，我們帶來更多活動，為此推廣台灣Furry的生態。
          我們原至一間餐廳，轉變而成的中小型聚會活動。
        </p>
        <br />
        <p class="text-base text-gray-900 tracking-wider">
          希望大家能夠共同體驗，當年最後一天的聚會。
        </p>
      </div>
    </div>
    <div class="mb-5 sm:mb-0 w-full">
      <img src="@/assets/img/about.png" alt="siteView" class="w-full h-full" />
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
