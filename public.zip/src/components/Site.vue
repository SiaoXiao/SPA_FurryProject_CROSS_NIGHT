<template>
  <div>
    <div
      class="max-w-screen-xl h-full w-full flex justify-center items-center flex-col-reverse sm:flex-row"
    >
      <div class="mb-5 sm:mb-0 w-full">
        <img
          src="@/assets/img/10001.jpg"
          alt="siteView"
          class="w-full h-full"
        />
      </div>
      <div class="flex justify-center items-center flex-col gap-2 w-full">
        <h2
          class="text-2xl text-gray-900 tracking-wider flex flex-col justify-center items-center"
        >
          12/31 NIGHT
          <span class="text-sm text-gray-500 tracking-wider">
            NIGHT PARTY
          </span>
        </h2>
        <ul class="text-gray-900 tracking-wide text-base">
          <li>19:30 - 20:00 毛毛扮演者 先行放置入場</li>
          <li>20:00 - 20:30 貴賓入場</li>
          <li>20:30 - 21:00 開幕會-活動介紹、投放摸彩</li>
          <li>21:00 - 22:00 DJ表演時間</li>
          <li>22:00 - 23:00 團康類活動</li>
          <li>24:00 - 01:00 抽獎、閉幕，活動結束</li>
        </ul>
      </div>
    </div>
    <div
      
       class="max-w-screen-xl h-full w-full flex justify-center items-center flex-col sm:flex-row mt-5 sm:mt-0"
    >
      <div class="flex justify-center items-center flex-col gap-2 w-full">
        <h2 class="text-2xl text-gray-900 tracking-wider">活動場地</h2>
        <span class="text-sm text-gray-500 tracking-wider" @click="ovo">
          玩劇島小劇場 Little Play
        </span>

        <a
          href="https://www.littleplaytaichung.com/"
          target="_blank"
          class="mt-5 text-white bg-gray-500 py-3 px-5 rounded shadow-lg hover:bg-gray-400 transition-all duration-200"
          >關於場地</a
        >
      </div>
      <div class="mb-5 sm:mb-0 w-full">
        <img
          src="@/assets/img/10014.jpg"
          alt="siteView"
          class="w-full h-full"
        />
      </div>
    </div>
  </div>
</template>
